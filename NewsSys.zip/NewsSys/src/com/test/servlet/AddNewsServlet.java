package com.test.servlet;

import com.test.dao.NewsDao;
import com.test.dao.NewsDaoInter;
import com.test.pojo.News;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/AddNewsServlet")
public class AddNewsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        //防止中文乱码
        String type=request.getParameter("type");
        String title= request.getParameter("title");
        String author=request.getParameter("author");
        String cdate=request.getParameter("cdate");
        String mdate="";
        String content = request.getParameter("content");
        News news =new News(type,title,author,cdate,mdate,content);
        NewsDaoInter newsDaoInter=new NewsDao();
        newsDaoInter.addNews(news);
        //System.out.println(cdate);
        //System.out.println(news);
        //System.out.println(newsDaoInter.addNews(news));
        //资源跳转
        request.getRequestDispatcher("GetAllServlet").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
